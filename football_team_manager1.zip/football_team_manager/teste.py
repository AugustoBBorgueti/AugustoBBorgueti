import sqlite3

conn = sqlite3.connect('C:/Users/augus/Desktop/football_team_manager/instance/football_team.db')
cursor = conn.cursor()
cursor.execute('SELECT SQLITE_VERSION()')
data = cursor.fetchone()
print(f"SQLite version: {data[0]}")
conn.close()
