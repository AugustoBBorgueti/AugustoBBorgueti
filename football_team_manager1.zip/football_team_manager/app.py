from flask import Flask, flash, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from datetime import datetime

app = Flask(__name__)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///C:/Users/augus/Desktop/football_team_manager/instance/football_team.db'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False
app.secret_key = 'sua_chave_secreta_aqui'  # Defina sua chave secreta aqui

db = SQLAlchemy(app)

# Definição dos modelos (Jogador, Jogo e Gol)
class Jogador(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    nome = db.Column(db.String(100), nullable=False)
    idade = db.Column(db.Integer, nullable=False)
    posicao = db.Column(db.String(50), nullable=False)
    time = db.Column(db.String(100), default='Sem Time')  # Valor padrão definido
    

class Jogo(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    data = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    vencedor = db.Column(db.String(100), nullable=False)
    gols = db.relationship('Gol', backref='jogo', lazy=True)

class Gol(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    jogador_id = db.Column(db.Integer, db.ForeignKey('jogador.id'), nullable=False)
    jogo_id = db.Column(db.Integer, db.ForeignKey('jogo.id'), nullable=False)
    quantidade = db.Column(db.Integer, nullable=False)


# Rota para consultar jogadores (lista e opções de editar/deletar)
@app.route('/consultar_jogadores')
def consultar_jogadores():
    jogadores = Jogador.query.all()
    return render_template('consultar_jogadores.html', jogadores=jogadores)

# Rota para exibir o artilheiro
@app.route('/top_scorer')
def top_scorer():
    # Realiza a consulta para encontrar o artilheiro
    artilheiro = Jogador.query.join(Gol).group_by(Jogador.id).order_by(db.func.count(Gol.id).desc()).first()
    return render_template('top_scorer.html', jogador=artilheiro)

@app.route('/gols_por_jogador')
def gols_por_jogador():
    jogadores = Jogador.query.all()
    gols_por_jogador = {jogador.id: 0 for jogador in jogadores}

    gols = Gol.query.all()
    for gol in gols:
        if gol.jogador_id in gols_por_jogador:
            gols_por_jogador[gol.jogador_id] += gol.quantidade

    return render_template('gols_por_jogador.html', jogadores=jogadores, gols_por_jogador=gols_por_jogador)


# Rota para exibir o time vencedor
@app.route('/winning_team')
def winning_team():
    jogos = Jogo.query.all()
    vitorias = {}
    
    for jogo in jogos:
        if jogo.vencedor in vitorias:
            vitorias[jogo.vencedor] += 1
        else:
            vitorias[jogo.vencedor] = 1
    
    time_vencedor = max(vitorias, key=vitorias.get)
    
    return render_template('winning_team.html', winning_team=time_vencedor)

# Rota para exibir o artilheiro mensal
@app.route('/monthly_top_scorer')
def monthly_top_scorer():
    current_month = datetime.now().month
    jogadores = Jogador.query.all()
    mensal_scores = {jogador.nome: 0 for jogador in jogadores}
    jogos = Jogo.query.filter(db.func.extract('month', Jogo.data) == current_month).all()
    
    for jogo in jogos:
        for jogador in jogadores:
            gols_jogador = sum(gol.quantidade for gol in jogo.gols if gol.jogador_id == jogador.id)
            mensal_scores[jogador.nome] += gols_jogador
    
    artilheiro_mensal = max(mensal_scores, key=mensal_scores.get)
    
    return render_template('monthly_top_scorer.html', monthly_top_scorer=artilheiro_mensal)

# Rota para página inicial (lista de jogadores e jogos)
@app.route('/')
def index():
    jogadores = Jogador.query.all()
    jogos = Jogo.query.all()
    return render_template('index.html', jogadores=jogadores, jogos=jogos)


# Rota para adicionar jogador
@app.route('/add_player', methods=['GET', 'POST'])
def add_player():
    if request.method == 'POST':
        nome = request.form['nome']
        idade = int(request.form['idade'])
        posicao = request.form['posicao']
        time = request.form['time'] if request.form['time'] else None

        # Verifica se o jogador já existe pelo nome
        jogador_existente = Jogador.query.filter_by(nome=nome).first()

        if jogador_existente:
            flash('Jogador já existe!', 'error')
            return redirect(url_for('add_player'))

        novo_jogador = Jogador(nome=nome, idade=idade, posicao=posicao, time=time)

        try:
            db.session.add(novo_jogador)
            db.session.commit()
            flash('Jogador adicionado com sucesso!', 'success')
            return redirect(url_for('add_player'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao adicionar jogador: {str(e)}', 'error')
            return redirect(url_for('add_player'))
    else:
        return render_template('add_player.html')
    
    # Rota para deletar jogador
@app.route('/delete_player/<int:jogador_id>', methods=['POST'])
def delete_player(jogador_id):
    jogador = Jogador.query.get_or_404(jogador_id)
    
    try:
        db.session.delete(jogador)
        db.session.commit()
        flash('Jogador deletado com sucesso!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao deletar jogador: {str(e)}', 'error')
    
    return redirect(url_for('index'))


# Rota para adicionar jogo
@app.route('/add_game', methods=['GET', 'POST'])
def add_game():
    if request.method == 'POST':
        data = datetime.strptime(request.form['data'], '%Y-%m-%d')
        vencedor = request.form['vencedor']

        jogadores_gols = []
        for i in range(1, 21):  # Assumindo até 20 jogadores por jogo
            jogador_nome = request.form.get(f'jogador_{i}')
            gols = int(request.form.get(f'gols_jogador_{i}', 0))
            if jogador_nome:
                jogadores_gols.append({'nome': jogador_nome, 'gols': gols})

        try:
            # Atualiza gols dos jogadores
            for jogador_gols in jogadores_gols:
                jogador = Jogador.query.filter_by(nome=jogador_gols['nome']).first()
                if jogador:
                    jogador.gols += jogador_gols['gols']
                    db.session.add(jogador)

            # Cria o novo jogo
            novo_jogo = Jogo(data=data, vencedor=vencedor)
            db.session.add(novo_jogo)
            db.session.commit()

            flash('Jogo adicionado com sucesso!', 'success')
            return redirect(url_for('index'))
        except Exception as e:
            db.session.rollback()
            flash(f'Erro ao adicionar jogo: {str(e)}', 'error')
            return redirect(url_for('index'))
    else:
        jogadores = Jogador.query.all()
        return render_template('add_game.html', jogadores=jogadores)
      


# Rota para adicionar gols por jogador em um jogo
@app.route('/add_gols', methods=['POST'])
def add_gols():
    jogo_id = int(request.form['jogo_id'])
    gols = request.form.getlist('gols[]')
    
    try:
        for gol in gols:
            jogador_id, quantidade = map(int, gol.split(':'))
            novo_gol = Gol(jogo_id=jogo_id, jogador_id=jogador_id, quantidade=quantidade)
            db.session.add(novo_gol)
        
        db.session.commit()
        flash('Gols adicionados com sucesso!', 'success')
    except Exception as e:
        db.session.rollback()
        flash(f'Erro ao adicionar gols: {str(e)}', 'error')
    
    return redirect(url_for('index'))

if __name__ == "__main__":
    with app.app_context():
        db.create_all()
    app.run(debug=True)
